Instructions:

a. Copy the two .rb files in a folder
b. Run the program learn_regular_expression.rb
c. Type and understand whatever you see as the output of the program
d. By the end, you would have learnt and covered Ruby Regular expressions.

Credit: 
a. Program regular_expression.rb by James Edward Gray II
b. Program learn_regular_expression.rb by Satoshi Asakawa

Have fun!